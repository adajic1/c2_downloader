Changelog
=========

The CasperJS changelog is `hosted on github <https://github.com/casperjs/casperjs/blob/master/CHANGELOG.md#casperjs-changelog>`_.
